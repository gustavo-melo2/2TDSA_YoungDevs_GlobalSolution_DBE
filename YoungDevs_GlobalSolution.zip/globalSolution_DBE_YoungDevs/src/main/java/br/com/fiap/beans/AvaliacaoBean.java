package br.com.fiap.beans;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import br.com.fiap.dao.AvaliacaoDao;
import br.com.fiap.model.Avaliacao;

@Named
@RequestScoped
public class AvaliacaoBean {

	private Avaliacao avaliacao = new Avaliacao();
	
	public List<Avaliacao> getAvaliacoes(){
		return new AvaliacaoDao().getAll();
	} 
	
	public List<Avaliacao> getAvaliacaoByHotel(int idHotel){
		return new AvaliacaoDao().getByIdHotel( idHotel );
	}

	public Avaliacao getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(Avaliacao avaliacao) {
		this.avaliacao = avaliacao;
	}


}
