package br.com.fiap.beans;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.application.NavigationHandler;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import br.com.fiap.dao.UsuarioDao;
import br.com.fiap.model.Usuario;

@Named
@RequestScoped
public class UsuarioBean {

	private Usuario usuario = new Usuario();

	public void save() {
		new UsuarioDao().save(this.usuario);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Cadastrado com sucesso!"));
		System.out.println(this.usuario);
		
		FacesContext context = FacesContext.getCurrentInstance();
		NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
		navigationHandler.handleNavigation(context, "", "login?faces-redirect=true" );
	}
	
	public void updateUsuario() {
		Usuario usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
		this.usuario.setId(usuario.getId());
		new UsuarioDao().update(this.usuario);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Atualizado com sucesso!"));
		System.out.println(this.usuario);
		
		FacesContext context = FacesContext.getCurrentInstance();
		NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
		navigationHandler.handleNavigation(context, "", "profile?faces-redirect=true" );
	}
	
	public void destroy() {
		Usuario usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
		this.usuario.setId(usuario.getId());
		new UsuarioDao().destroy(this.usuario);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Deletado com sucesso!"));
		System.out.println(this.usuario);
		
		FacesContext context = FacesContext.getCurrentInstance();
		NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("user");
		navigationHandler.handleNavigation(context, "", "login?faces-redirect=true" );
		
	}
	
	public List<Usuario> getUsers(){
		return new UsuarioDao().getAll();
	}
	
	public Usuario getUserById() {
		Usuario usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
		return usuario;
	}

	public Usuario getUser() {
		return usuario;
	}

	public void setUser(Usuario usuario) {
		this.usuario = usuario;
	}
	
	public String login() {
		Usuario usuarioLogin = new UsuarioDao().exist(usuario);
		if ( usuarioLogin != null ) {
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user", usuarioLogin);
			return "index?faces-redirect=true";
		}
		FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login Inválido!", "erro"));
		return "login?faces-redirect=true";		
	}
	
	public String logout() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("user");
		return "login?faces-redirect=true";
	}
	
}
