package br.com.fiap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "T_APT_BAIRRO")
public class Bairro {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_bairro", length = 8)
	private int id;

	@Column(name = "nm_bairro", nullable = false, length = 45)
	private String nome;

	@Column(name = "dsc_bairro", length = 255)
	private String descricao;

	@Column(name = "nm_pais", nullable = false, length = 20)
	private String nomePais;

	@Column(name = "nm_cidade", nullable = false, length = 20)
	private String nomeCidade;
	
	@OneToMany(mappedBy = "bairro", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Hotel> hoteis;

	public Bairro() {
		super();
	}

	
	public Bairro(int id, String nome, String descricao, String nomePais, String nomeCidade) {
		super();
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.nomePais = nomePais;
		this.nomeCidade = nomeCidade;
	}

	public Bairro(String nome, String descricao, String nomePais, String nomeCidade) {
		super();
		this.nome = nome;
		this.descricao = descricao;
		this.nomePais = nomePais;
		this.nomeCidade = nomeCidade;
	}

	
	public void addHotel(Hotel hotel) {
		if (hoteis == null) {
			hoteis = new ArrayList<>();
		}
		hoteis.add(hotel);
		hotel.setBairro(this);
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}


	public String getNomePais() {
		return nomePais;
	}


	public void setNomePais(String nomePais) {
		this.nomePais = nomePais;
	}


	public String getNomeCidade() {
		return nomeCidade;
	}


	public void setNomeCidade(String nomeCidade) {
		this.nomeCidade = nomeCidade;
	}


	public List<Hotel> getHoteis() {
		return hoteis;
	}


	public void setHoteis(List<Hotel> hoteis) {
		this.hoteis = hoteis;
	}	
	
}
