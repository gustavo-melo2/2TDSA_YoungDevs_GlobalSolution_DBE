package br.com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.model.Quarto;
import br.com.fiap.util.EntityManagerFacade;

public class QuartoDao {
	
	private EntityManager manager = new EntityManagerFacade().getEntityManager();
	
	public List<Quarto> getQuartos(int idHotel) {
		TypedQuery<Quarto> query = manager.createQuery("select h from Quarto h where h.hotel.id = :idHotel", Quarto.class);
		query.setParameter("idHotel", idHotel);
		return query.getResultList();
	}

}