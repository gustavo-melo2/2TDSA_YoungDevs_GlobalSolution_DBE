package br.com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.model.Avaliacao;
import br.com.fiap.util.EntityManagerFacade;

public class AvaliacaoDao {
	
	private EntityManager manager = new EntityManagerFacade().getEntityManager();
	
	public void save(Avaliacao avaliacao) {
		manager.getTransaction().begin();
		manager.persist(avaliacao);
		manager.getTransaction().commit();
		manager.clear();
	}
	
	public List<Avaliacao> getAll() {
		String jpql = "select h from Avaliacao h";
		TypedQuery<Avaliacao> createQuery = manager.createQuery(jpql, Avaliacao.class);
		return createQuery.getResultList();
	}
	
	public List<Avaliacao> getByIdHotel(int idHotel) {
		TypedQuery<Avaliacao> query = manager.createQuery("select h from Avaliacao h where h.id_hotel = :idHotel", Avaliacao.class);
		query.setParameter("idHotel", idHotel);
		return query.getResultList();
	}

}
