package br.com.fiap.beans;

import java.util.List;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import br.com.fiap.dao.HotelDao;
import br.com.fiap.model.Hotel;

@Named
@RequestScoped
public class HotelBean {

	private Hotel hotel = new Hotel();
	
	public List<Hotel> getHoteis(){
		return new HotelDao().getAll();
	}
	
	public Hotel getHotelById(int idHotel) {
		return new HotelDao().findById(idHotel);
	}
	
	public Hotel getHotelByIdUrl() {
		FacesContext context = FacesContext.getCurrentInstance();
		Map<String,String> params = context.getExternalContext().getRequestParameterMap();
		String idString = params.get("id");
		int id = Integer.valueOf(idString);
		return new HotelDao().findById(id);
	}


	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}


}
