package br.com.fiap.rest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.fiap.dao.HotelDao;
import br.com.fiap.model.Hotel;

@Path("/hoteis")
@Produces(MediaType.APPLICATION_JSON)
public class HotelEndPoint {
	
	private HotelDao dao = new HotelDao();
	
	@GET
	public List<Hotel> index() {		
		return dao.getAll();		
	}

	
	@GET
	@Path("{id}")
	public Response show(@PathParam("id") int id ) {
		
		if ( id == 0 ) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
		
		Hotel hotel = dao.findById(id);
		
		if ( hotel == null ) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		
		return Response.status(Response.Status.OK).entity(hotel).build(); 
	}
	
	
	
}
