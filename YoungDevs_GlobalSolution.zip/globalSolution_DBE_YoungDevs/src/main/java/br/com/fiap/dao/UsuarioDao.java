package br.com.fiap.dao;

import java.util.List;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import br.com.fiap.model.Usuario;
import br.com.fiap.util.EntityManagerFacade;

public class UsuarioDao {

	private EntityManager manager = new EntityManagerFacade().getEntityManager();
	
	public void save(Usuario usuario) {
		
		manager.getTransaction().begin();
		manager.persist(usuario);
		manager.getTransaction().commit();

		manager.clear();

	}
	
	public List<Usuario> getAll() {
		String jpql = "SELECT s FROM Usuario s";
		TypedQuery<Usuario> createQuery = manager.createQuery(jpql, Usuario.class);
		return createQuery.getResultList();
	}

	public Usuario findById(int id) {
		return manager.find(Usuario.class, id);
	}
	
	public void update(Usuario usuario) {
		manager.getTransaction().begin();
		manager.merge(usuario);
		manager.flush();
		manager.getTransaction().commit();
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("user");
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user", usuario);
	}

	public void destroy(Usuario usuario) {
		manager.getTransaction().begin();
		manager.remove(usuario);
		manager.flush();
		manager.getTransaction().commit();	
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("user");
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user", usuario);
	}

	public Usuario exist(Usuario usuario) {
		TypedQuery<Usuario> query = manager.createQuery("SELECT u FROM Usuario u WHERE "
							+ "email=:email AND " 
							+ "senha=:password",
							Usuario.class);
		query.setParameter("email", usuario.getEmail());
		query.setParameter("password", usuario.getSenha());
		
		try {
			Usuario result = query.getSingleResult();
			System.out.println(result);
			return result;
		} catch (NoResultException e) {
			System.out.println("Erro");
			return null;
		}
	}
	
	public Usuario select(int id) throws EntityNotFoundException {
		Usuario entidade = manager.find(Usuario.class, id);
		if(entidade == null) {
			throw new EntityNotFoundException();
		}
		return entidade;
	}
	
	
	
}

