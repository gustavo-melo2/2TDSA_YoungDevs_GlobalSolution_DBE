package br.com.fiap.model;

import java.io.Serializable;

public class AvaliacaoPK implements Serializable{	
	private static final long serialVersionUID = 1L;

	private int id;
	
	private int hotel;
	
	private int usuario;

	public AvaliacaoPK() {
		super();
	}
	
	public AvaliacaoPK(int id, int hotel, int usuario) {
		super();
		this.id = id;
		this.hotel = hotel;
		this.usuario = usuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + hotel;
		result = prime * result + id;
		result = prime * result + usuario;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AvaliacaoPK other = (AvaliacaoPK) obj;
		if (hotel != other.hotel)
			return false;
		if (id != other.id)
			return false;
		if (usuario != other.usuario)
			return false;
		return true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHotel() {
		return hotel;
	}

	public void setHotel(int hotel) {
		this.hotel = hotel;
	}

	public int getUsuario() {
		return usuario;
	}

	public void setUsuario(int usuario) {
		this.usuario = usuario;
	}

	
	
	
	
}
