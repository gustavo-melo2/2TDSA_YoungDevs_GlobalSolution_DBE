package br.com.fiap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "T_TVL_QUARTO")
public class Quarto {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_quarto", length = 9)
	private int id;
	
	@Column(name="nm_quarto", nullable = false, length = 90)
	private String nmQuarto;
	
	@Column(name = "dsc_quarto", nullable = false, length = 255)
	private String descricao;

	@Column(name = "pr_quarto", nullable = false)
	private double preco;
	
	@ManyToOne
	@JoinColumn(name = "id_hotel")
	private Hotel hotel;
	
	public Quarto() {
		super();
	}

	public Quarto(int id, String nmQuarto, String descricao, double preco) {
		super();
		this.id = id;
		this.nmQuarto = nmQuarto;
		this.descricao = descricao;
		this.preco = preco;
	}

	public Quarto(String nmQuarto, String descricao, double preco) {
		super();
		this.nmQuarto = nmQuarto;
		this.descricao = descricao;
		this.preco = preco;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNmQuarto() {
		return nmQuarto;
	}

	public void setNmQuarto(String nmQuarto) {
		this.nmQuarto = nmQuarto;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	
	
}
