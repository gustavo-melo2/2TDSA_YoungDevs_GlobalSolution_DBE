package br.com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.TypedQuery;
import br.com.fiap.model.Hotel;
import br.com.fiap.util.EntityManagerFacade;

public class HotelDao {
	

	private EntityManager manager = new EntityManagerFacade().getEntityManager();
	
	public List<Hotel> getAll() {
		String jpql = "select h from Hotel h";
		TypedQuery<Hotel> createQuery = manager.createQuery(jpql, Hotel.class);
		return createQuery.getResultList();
	}
	
	public List<Hotel> listarPorBairro(int idBairro) {
		TypedQuery<Hotel> query = manager.createQuery("select h from Hotel h where h.bairro.id = :idBairro", Hotel.class);
		query.setParameter("idBairro", idBairro);
		return query.getResultList();
	}

	public Hotel findById(int id) {
		return manager.find(Hotel.class, id);
	}

	public void update(Hotel user) {
		manager.getTransaction().begin();
		manager.merge(user);
		manager.flush();
		manager.getTransaction().commit();
	}

	public void destroy(Hotel user) {
		manager.getTransaction().begin();
		manager.remove(user);
		manager.flush();
		manager.getTransaction().commit();	
	}
	
	public Hotel select(int id) throws EntityNotFoundException {
		Hotel entidade = manager.find(Hotel.class, id);
		if(entidade == null) {
			throw new EntityNotFoundException();
		}
		return entidade;
	}
	
	public List<Hotel> listarPorNumEstrelas(int numEstrelas) {
		TypedQuery<Hotel> query = manager.createQuery("select h from Hotel h where h.numeroEstrelas = :numEstrelas", Hotel.class);
		query.setParameter("numEstrelas", numEstrelas);
		return query.getResultList();
	}
	
	
	
}


