package br.com.fiap.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "T_TVL_HOTEL")
public class Hotel {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_hotel", length = 8)
	private int id;
	
	@Column(name="nm_hotel", nullable = false, length = 45)
	private String nome;
	
	@Column(name="dsc_hotel", nullable = false, length = 355)
	private String descricao;
	
	@Column(name="ph_imagem", nullable = false, length = 60)
	private String pathImagem;
	
	@Column(name = "nr_estrelas", nullable = false, length = 1)
	private int numeroEstrelas;
	
	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Quarto> quartos;

	@ManyToOne
	@JoinColumn(name = "id_bairro", nullable = false)
	private Bairro bairro;
	
	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Avaliacao> avaliacoes;
	
	
	public Hotel() {
		super();
	}


	public Hotel(int id, String nome, String descricao, String pathImagem, int numeroEstrelas) {
		super();
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.pathImagem = pathImagem;
		this.numeroEstrelas = numeroEstrelas;
	}


	public Hotel(String nome, String descricao, String pathImagem, int numeroEstrelas) {
		super();
		this.nome = nome;
		this.descricao = descricao;
		this.pathImagem = pathImagem;
		this.numeroEstrelas = numeroEstrelas;
	}


	public void addQuarto(Quarto quarto) {
		if (quartos == null) {
			quartos = new ArrayList<>();
		}
		quartos.add(quarto);
		quarto.setHotel(this);
	}
	
	public void addAvaliacao(Avaliacao avaliacao) {
		if (avaliacoes == null) {
			avaliacoes = new ArrayList<>();
		}
		avaliacoes.add(avaliacao);
		avaliacao.setHotel(this);
	}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}


	public String getPathImagem() {
		return pathImagem;
	}


	public void setPathImagem(String pathImagem) {
		this.pathImagem = pathImagem;
	}


	public int getNumeroEstrelas() {
		return numeroEstrelas;
	}


	public void setNumeroEstrelas(int numeroEstrelas) {
		this.numeroEstrelas = numeroEstrelas;
	}


	public List<Quarto> getQuartos() {
		return quartos;
	}


	public void setQuartos(List<Quarto> quartos) {
		this.quartos = quartos;
	}


	public Bairro getBairro() {
		return bairro;
	}


	public void setBairro(Bairro bairro) {
		this.bairro = bairro;
	}


	public List<Avaliacao> getAvaliacoes() {
		return avaliacoes;
	}


	public void setAvaliacoes(List<Avaliacao> avaliacoes) {
		this.avaliacoes = avaliacoes;
	}
	
	
	
}
