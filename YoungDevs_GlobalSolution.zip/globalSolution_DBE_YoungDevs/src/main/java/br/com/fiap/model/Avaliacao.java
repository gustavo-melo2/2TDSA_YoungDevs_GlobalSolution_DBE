package br.com.fiap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@IdClass(AvaliacaoPK.class)
@Entity
@Table(name = "T_TVL_AVALIACAO")
public class Avaliacao {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id_avaliacao", length = 8)
	private int id;
	
	@Id
	@ManyToOne
	@JoinColumn(name="id_hotel")
	private Hotel hotel;
	
	@Id
	@ManyToOne
	@JoinColumn(name="id_usuario")
	private Usuario usuario;
	
	@Column(name="nr_estrelas", nullable = false, length = 1)
	private int numEstrelas;
	
	@Column(name="txt_avaliacao", nullable = false, length = 255)
	private String txtAvaliacao;

	
	public Avaliacao() {
		super();
	}
	
	public Avaliacao(int numEstrelas, String txtAvaliacao) {
		super();
		this.numEstrelas = numEstrelas;
		this.txtAvaliacao = txtAvaliacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public int getNumEstrelas() {
		return numEstrelas;
	}

	public void setNumEstrelas(int numEstrelas) {
		this.numEstrelas = numEstrelas;
	}

	public String getTxtAvaliacao() {
		return txtAvaliacao;
	}

	public void setTxtAvaliacao(String txtAvaliacao) {
		this.txtAvaliacao = txtAvaliacao;
	}

	
}