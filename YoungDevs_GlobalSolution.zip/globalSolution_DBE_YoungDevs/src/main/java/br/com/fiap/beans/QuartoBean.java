package br.com.fiap.beans;

import java.util.List;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import br.com.fiap.dao.QuartoDao;
import br.com.fiap.model.Quarto;

@Named
@RequestScoped
public class QuartoBean {
	
	private Quarto quarto = new Quarto();
	
	public List<Quarto> getQuartoByHotel(){	
		FacesContext context = FacesContext.getCurrentInstance();
		Map<String,String> params = context.getExternalContext().getRequestParameterMap();
		String idString = params.get("id");
		int id = Integer.valueOf(idString);
		return new  QuartoDao().getQuartos(id);		
	}

	public Quarto getQuarto() {
		return quarto;
	}

	public void setQuarto(Quarto quarto) {
		this.quarto = quarto;
	}
	
}
