package br.com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.model.Bairro;
import br.com.fiap.util.EntityManagerFacade;

public class BairroDao {
	
	private EntityManager manager = new EntityManagerFacade().getEntityManager();
	
	public List<Bairro> getAll() {
		String jpql = "select b from Bairro b";
		TypedQuery<Bairro> createQuery = manager.createQuery(jpql, Bairro.class);
		return createQuery.getResultList();
	}

}
